<?php

declare(strict_types=1);

namespace Drupal\prono_rencontre\Entity;

use Drupal\Core\Entity\Attribute\ContentEntityType;
use Drupal\Core\Entity\ContentEntityBase;
use Drupal\Core\Entity\ContentEntityDeleteForm;
use Drupal\Core\Entity\Form\DeleteMultipleForm;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\prono_rencontre\Form\RencontreForm;
use Drupal\prono_rencontre\RencontreAccessControlHandler;
use Drupal\prono_rencontre\RencontreInterface;
use Drupal\prono_rencontre\RencontreListBuilder;
use Drupal\prono_rencontre\Routing\RencontreHtmlRouteProvider;
use Drupal\views\EntityViewsData;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Field\BaseFieldDefinition;

/**
 * Defines the rencontre entity class.
 */
#[ContentEntityType(
  id: 'prono_rencontre',
  label: new TranslatableMarkup('Rencontre'),
  label_collection: new TranslatableMarkup('Rencontres'),
  label_singular: new TranslatableMarkup('rencontre'),
  label_plural: new TranslatableMarkup('rencontres'),
  entity_keys: [
    'id' => 'id',
    'label' => 'id',
    'uuid' => 'uuid',
  ],
  handlers: [
    'list_builder' => RencontreListBuilder::class,
    'views_data' => EntityViewsData::class,
    'access' => RencontreAccessControlHandler::class,
    'form' => [
      'add' => RencontreForm::class,
      'edit' => RencontreForm::class,
      'delete' => ContentEntityDeleteForm::class,
      'delete-multiple-confirm' => DeleteMultipleForm::class,
    ],
    'route_provider' => [
      'html' => RencontreHtmlRouteProvider::class,
    ],
  ],
  links: [
    'collection' => '/admin/content/prono-rencontre',
    'add-form' => '/prono-rencontre/add',
    'canonical' => '/prono-rencontre/{prono_rencontre}',
    'edit-form' => '/prono-rencontre/{prono_rencontre}',
    'delete-form' => '/prono-rencontre/{prono_rencontre}/delete',
    'delete-multiple-form' => '/admin/content/prono-rencontre/delete-multiple',
  ],
  admin_permission: 'administer prono_rencontre',
  base_table: 'prono_rencontre',
  label_count: [
    'singular' => '@count rencontres',
    'plural' => '@count rencontres',
  ],
  field_ui_base_route: 'entity.prono_rencontre.settings',
)]
class Rencontre extends ContentEntityBase implements RencontreInterface {

  public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {
    
    $fields['id'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('ID'))
      ->setDescription(t('The ID of the Advertiser entity.'))
      ->setReadOnly(TRUE);

    $fields['uuid'] = BaseFieldDefinition::create('uuid')
      ->setLabel(t('UUID'))
      ->setDescription(t('The UUID of the Advertiser entity.'))
      ->setReadOnly(TRUE);

    $fields['equipe_domicile'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Equipe Domicile'))
      ->setDescription(t('Nom de l\'équipe domicile.'))
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['equipe_exterieur'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Equipe Exterieur'))
      ->setDescription(t('Nom de l\'équipe exterieur.'))
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['journee'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel(t('Journée'))
      ->setDescription(t('Référence à la journée.'))
      ->setSetting('target_type', 'node')
      ->setSetting('handler', 'default')
      ->setSetting('handler_settings', [
        'target_bundles' => [
          'journee' => 'journee',
        ],
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['date_debut'] = BaseFieldDefinition::create('datetime')
      ->setLabel(t('Date debut'))
      ->setDescription(t('Date de la rencontre.'))
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    // $fields['equipe_exterieur'] = BaseFieldDefinition::create('datetime')
    //   ->setLabel(t('Equipe Exterieur'))
    //   ->setDescription(t('Nom de l\'équipe exterieur.'))
    //   ->setDisplayConfigurable('form', TRUE)
    //   ->setDisplayConfigurable('view', TRUE);

    $fields['score_domicile'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('Score domicile'))
      ->setDescription(t('Score de l\'équipe domicile.'))
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['score_exterieur'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('Score exterieur'))
      ->setDescription(t('Score de l\'équipe exterieur.'))
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    return $fields;
  }
}

